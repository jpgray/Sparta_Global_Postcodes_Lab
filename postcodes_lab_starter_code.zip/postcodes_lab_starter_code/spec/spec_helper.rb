require 'rspec'
require_relative '../postcode'


RSpec.configure do |config|
  config.color = true
  config.formatter = :documentation
end


